package logger;

import java.util.ArrayList;

/**
 *
 * @author Mohammad Dehghan
 */
public class FileLogger implements Logger {

    @Override
    public void log(String ssn, String description) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<ArrayList<String>> showLogs(String startDate, String endDate) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
