package services;

/**
 *
 * @author Mohammad
 */
public class ViewBag {

    public static String Title = "Login";

    public static int runningApps = 0;
}
