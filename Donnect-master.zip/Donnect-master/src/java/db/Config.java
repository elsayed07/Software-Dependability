package db;

/**
 *
 * @author Mohammad
 */
public class Config {

    static String DB_USER = "user";
    static String DB_PASSWORD = "password";
    static String DB_DATABASE = "divice";
    static String DB_SERVER = "jdbc:mysql://localhost/";
    static String DB_PORT = "1527";
}
