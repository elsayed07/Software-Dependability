package models.tasks;

/**
 *
 * @author Mohammad
 */
public class Task {

}
